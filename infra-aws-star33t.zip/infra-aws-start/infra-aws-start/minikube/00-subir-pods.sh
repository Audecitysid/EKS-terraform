kubectl apply -f ./componentes/namespace-monitoring.yaml

#kubectl create -f ../eks/kube-prometheus/manifests/setup/
#kubectl create -f ../eks/kube-prometheus/manifests/
kubectl apply -f ./componentes/influxdb-persistentvolumeclaim.yaml
kubectl apply -f ./componentes/influxdb-statefulSet.yaml
kubectl apply -f ./componentes/influxdb-service.yaml



kubectl apply -f ./componentes/configmap-donodoapp.yaml --validate=false

kubectl apply -f ./componentes/bd-ddadb-persistentvolumeclaim.yaml
kubectl apply -f ./componentes/bd-ddadb-statefulset.yaml --validate=false
kubectl apply -f ./componentes/bd-ddadb-service.yaml

#kubectl apply -f ./componentes/adminer-statefulset.yaml
#kubectl apply -f ./componentes/adminer-service.yaml

#kubectl apply -f ./componentes/donodoapp-hpa.yaml

kubectl apply -f ./componentes/grafana.yaml
kubectl apply -f ./componentes/grafana-service.yaml
kubectl apply -f ./componentes/donodoapp-deployment.yaml
kubectl apply -f ./componentes/donodoapp-service.yaml

kubectl apply -f ./componentes/ingress.yaml
