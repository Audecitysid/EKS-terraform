from locust import FastHttpUser, task

class WebsiteUser(FastHttpUser): 

    host = "http://localhost:8089"

    @task 
    def get_markets(self):
#        self.client.get("/")
        with self.client.get("/", catch_response=True) as response:
            if response.status_code == 429:
               raise RescheduleTask()


