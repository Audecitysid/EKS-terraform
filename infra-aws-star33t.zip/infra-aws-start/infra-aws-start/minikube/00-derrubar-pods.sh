
kubectl delete svc --all

kubectl delete statefulset --all

kubectl delete deploy --all

kubectl delete pvc --all

kubectl delete cm --all

kubectl delete hpa --all

kubectl delete -f ./componentes/ingress.yaml

#kubectl delete -f ./componentes/service-monitor-nginx.yaml


#kubectl delete -f ../eks/kube-prometheus/manifests/setup/

#kubectl delete -f ../eks/kube-prometheus/manifests/


kubectl delete -f ./componentes/namespace-monitoring.yaml









