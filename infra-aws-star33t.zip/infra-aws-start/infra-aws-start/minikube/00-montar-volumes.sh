minikube mount ./init-pods:/data/init-pods

