kubectl exec -it deployment.apps/deploy-donodoapp -- sh -c "php artisan reset:demo"
kubectl exec -it deployment.apps/deploy-donodoapp -- sh -c "php artisan session:table"
kubectl exec -it deployment.apps/deploy-donodoapp -- sh -c "php artisan migrate"
