#SCRIPT UTILIZADA PARA DAR ACESSO A DETERMINADO USUÁRIO AO CLUSTER EKS, UTILIZANDO UM GRUPO EXISTENTE OU O GRUPO CUSTOMIZADO
#NO ARQUIVO eks-role-custom-access-group.tf
USUARIO=terraform-cicero

eksctl create iamidentitymapping \
    --cluster eks-01 \
    --region=us-east-2 \
    --arn arn:aws:iam::002379016991:user/$USUARIO \
    --username $USUARIO \
    --group "system:masters" \
    --no-duplicate-arns

# se quiser usar o acesso personalizado pelo terraform no arquivo eks-role-custom-access-group.tf, usar o group "eks-cluster-full-access-group"
# se quiser usar o acesso total, usar o group "system:masters"



      
