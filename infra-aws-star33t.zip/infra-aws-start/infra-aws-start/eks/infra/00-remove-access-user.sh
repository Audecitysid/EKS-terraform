#SCRIPT UTILIZADO PARA REMOVER O ACESSO DE DETERMINADO USUÁRIO AO CLUSTER EKS

USUARIO=davicarrano

eksctl delete iamidentitymapping \
    --cluster eks-01 \
    --region=us-east-2 \
    --arn arn:aws:iam::002379016991:user/$USUARIO