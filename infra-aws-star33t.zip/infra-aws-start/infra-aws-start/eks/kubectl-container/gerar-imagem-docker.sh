IMAGEM=002379016991.dkr.ecr.us-east-2.amazonaws.com/donodoapp/kubectl-container
VERSAO=v1.0
REGIAO_AWS=us-east-2
CLUSTER_EKS=eks-01

aws ecr --profile donodoapp get-login-password --region $REGIAO_AWS | docker login --username AWS --password-stdin 002379016991.dkr.ecr.us-east-2.amazonaws.com
docker build -t $IMAGEM:$VERSAO -f kubectl-container.Dockerfile --build-arg REGION=$REGIAO_AWS --build-arg CLUSTER=$CLUSTER_EKS .
docker push $IMAGEM:$VERSAO